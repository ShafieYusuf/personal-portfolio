import React from 'react'
import './About.css'
function About() {
  return (
    <div className='beta'>
      <div className='lin4'></div>
      <div className='container4'>
        <div className='About1'>
          <h1 className='Ab'>contact Me</h1>
          {/* <br/> */}
          <h3>Email</h3>
          <p>shaaficiyuusuf80@gmail.com.com</p>
          <h3>Role</h3>
          <p className='develop'>Web developer</p>
          <h3>Phone</h3>
          <p>(252)<span> </span>252613482232</p>
        </div>
        <div className='About2'>
        <img className='im1' src="/images/lol12.jpg" alt="no thing" />
        </div>

      </div>
    </div>
  )
}

export default About;
