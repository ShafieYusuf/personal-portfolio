import React from 'react'
import './Skills.css'
function Skills() {
  return (
    <div></div>
  )
}

export default Skills
