import React from 'react'
import './Main.css'
function Main() {
  return (
    <div>
      <div class="container">
       <h1>I'am <span className='name'>shaafci</span><br/><span>Iam web developer</span><br/
       ><h7>Kusoo Dhawoow my Website*</h7></h1>
       <img src="/images/shaafka.jpg" alt="no thing" />
       <a className='button' href='###' >Show More</a>
       </div>
       
      
    </div>
  )
  }
export default Main
