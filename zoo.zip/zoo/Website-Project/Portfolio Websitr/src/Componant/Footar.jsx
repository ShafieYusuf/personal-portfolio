import React from 'react'
import './Footar.css';
function Footar() {
  return (
    <div>
      <div>
        <footer>
          <ul>
          
          </ul>
        </footer>
      </div>
    </div>
  )
}

export default Footar
