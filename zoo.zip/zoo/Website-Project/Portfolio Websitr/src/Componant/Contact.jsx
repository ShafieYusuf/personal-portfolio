import React from 'react';
import './Contact.css';

function Contact() {
  return (
    <div>
      
    </div>
  );
}

export default Contact;